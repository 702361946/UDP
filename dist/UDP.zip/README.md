>使用

configure.json里的IPv4有如下含义

| sys         | user       |
|-------------|------------|
| 服务器绑定的ip&端口 | 指定服务器地址和端口 |

key:"user input"的值为True时,将启用用户输入

key:"setblocking"的值为True将开启阻塞模式